window.__imported__ = window.__imported__ || {};
window.__imported__["sizing@1x/layers.json.js"] = [
	{
		"objectId": "C6B808DC-DC8B-4687-959A-D343F9D2792C",
		"kind": "artboard",
		"name": "Clothing",
		"originalName": "Clothing",
		"maskFrame": null,
		"layerFrame": {
			"x": 71,
			"y": 67,
			"width": 414,
			"height": 736
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "5BDC0119-FEF9-42FC-90A9-5F087754342F",
				"kind": "group",
				"name": "Group",
				"originalName": "Group",
				"maskFrame": null,
				"layerFrame": {
					"x": 96,
					"y": 54,
					"width": 220,
					"height": 423
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Group-nujeqzax.png",
					"frame": {
						"x": 96,
						"y": 54,
						"width": 220,
						"height": 423
					}
				},
				"children": [
					{
						"objectId": "CB81122B-7B19-45AF-B3F0-4B55D123541D",
						"kind": "group",
						"name": "MenInput",
						"originalName": "MenInput",
						"maskFrame": null,
						"layerFrame": {
							"x": 144.6666666666667,
							"y": 426.3333333333333,
							"width": 125,
							"height": 50
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-MenInput-q0i4mtey.png",
							"frame": {
								"x": 144.6666666666667,
								"y": 426.3333333333333,
								"width": 125,
								"height": 50
							}
						},
						"children": []
					},
					{
						"objectId": "11E2A170-B201-4F1E-A39D-6D8B84904710",
						"kind": "group",
						"name": "MenInput1",
						"originalName": "MenInput",
						"maskFrame": null,
						"layerFrame": {
							"x": 144.6666666666667,
							"y": 335.3333333333333,
							"width": 125,
							"height": 50
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-MenInput-mtffmkex.png",
							"frame": {
								"x": 144.6666666666667,
								"y": 335.3333333333333,
								"width": 125,
								"height": 50
							}
						},
						"children": []
					}
				]
			},
			{
				"objectId": "2FCD21EF-E598-43E8-ACE3-BFDF6FCE50FD",
				"kind": "group",
				"name": "Back",
				"originalName": "Back",
				"maskFrame": null,
				"layerFrame": {
					"x": -5,
					"y": -5,
					"width": 424,
					"height": 746
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Back-mkzdrdix.png",
					"frame": {
						"x": -5,
						"y": -5,
						"width": 424,
						"height": 746
					}
				},
				"children": []
			}
		]
	},
	{
		"objectId": "3F3F381F-C86C-4845-B8FC-532EC9D16986",
		"kind": "artboard",
		"name": "Style",
		"originalName": "Style",
		"maskFrame": null,
		"layerFrame": {
			"x": 628,
			"y": 67,
			"width": 414,
			"height": 736
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "F1D97A55-EF16-4D96-B4C5-3978D54A2F68",
				"kind": "group",
				"name": "Continue",
				"originalName": "Continue",
				"maskFrame": null,
				"layerFrame": {
					"x": 115,
					"y": 660,
					"width": 209,
					"height": 50
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Continue-rjfeotdb.png",
					"frame": {
						"x": 115,
						"y": 660,
						"width": 209,
						"height": 50
					}
				},
				"children": []
			},
			{
				"objectId": "74C819EB-6C2E-46B2-8DF8-49ECE3A9DDFC",
				"kind": "group",
				"name": "Top",
				"originalName": "Top",
				"maskFrame": null,
				"layerFrame": {
					"x": 21,
					"y": 53,
					"width": 317,
					"height": 52
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Top-nzrdode5.png",
					"frame": {
						"x": 21,
						"y": 53,
						"width": 317,
						"height": 52
					}
				},
				"children": []
			},
			{
				"objectId": "897851C6-61FB-4115-83CA-1D16B478566B",
				"kind": "group",
				"name": "Cover1",
				"originalName": "Cover1",
				"maskFrame": null,
				"layerFrame": {
					"x": 65,
					"y": 154,
					"width": 120,
					"height": 118
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Cover1-odk3odux.png",
					"frame": {
						"x": 65,
						"y": 154,
						"width": 120,
						"height": 118
					}
				},
				"children": []
			},
			{
				"objectId": "7DF97792-BE54-4B6B-8A91-D440612DF68C",
				"kind": "group",
				"name": "Cover2",
				"originalName": "Cover2",
				"maskFrame": null,
				"layerFrame": {
					"x": 224,
					"y": 466,
					"width": 120,
					"height": 119
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Cover2-n0rgotc3.png",
					"frame": {
						"x": 224,
						"y": 466,
						"width": 120,
						"height": 119
					}
				},
				"children": []
			},
			{
				"objectId": "78C60B92-FFFD-43FD-84D5-C068935BB850",
				"kind": "group",
				"name": "Onboarding_2",
				"originalName": "Onboarding_2",
				"maskFrame": null,
				"layerFrame": {
					"x": -5,
					"y": -5,
					"width": 425,
					"height": 746
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "321CF583-514F-4385-879E-4E38B4BFBCB7",
						"kind": "group",
						"name": "Outfits",
						"originalName": "Outfits",
						"maskFrame": null,
						"layerFrame": {
							"x": 62,
							"y": 148,
							"width": 290,
							"height": 439
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "310A18B7-DFE7-4E07-83CB-0DB18DDC61D6",
								"kind": "group",
								"name": "Outfit_1",
								"originalName": "Outfit_1",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4897881386352,
									"height": 117.1418980612181
								},
								"layerFrame": {
									"x": 227,
									"y": 148,
									"width": 125,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Outfit_1-mzewqte4.png",
									"frame": {
										"x": 227,
										"y": 148,
										"width": 125,
										"height": 123
									}
								},
								"children": []
							},
							{
								"objectId": "C8103886-FA5D-4F24-B31D-471930917467",
								"kind": "group",
								"name": "Cover_Outfit1",
								"originalName": "Cover_Outfit1",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4899638009714,
									"height": 117.1420702719137
								},
								"layerFrame": {
									"x": 62,
									"y": 152,
									"width": 125,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Cover_Outfit1-qzgxmdm4.png",
									"frame": {
										"x": 62,
										"y": 152,
										"width": 125,
										"height": 123
									}
								},
								"children": []
							},
							{
								"objectId": "014EA72D-F53B-48CF-8C4A-9A45D63DC62B",
								"kind": "group",
								"name": "Outfit_2",
								"originalName": "Outfit_2",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4899638009714,
									"height": 117.1420702719137
								},
								"layerFrame": {
									"x": 62,
									"y": 308,
									"width": 125,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Outfit_2-mde0rue3.png",
									"frame": {
										"x": 62,
										"y": 308,
										"width": 125,
										"height": 123
									}
								},
								"children": []
							},
							{
								"objectId": "034F0D8C-1105-4245-AD77-20EECEE00EA3",
								"kind": "group",
								"name": "Outfit_3",
								"originalName": "Outfit_3",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4899638009717,
									"height": 117.1420702719137
								},
								"layerFrame": {
									"x": 227,
									"y": 308,
									"width": 125,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Outfit_3-mdm0rjbe.png",
									"frame": {
										"x": 227,
										"y": 308,
										"width": 125,
										"height": 123
									}
								},
								"children": []
							},
							{
								"objectId": "C25AF733-18E7-4AC7-8CF8-A0B1944E71A0",
								"kind": "group",
								"name": "Cover_Outfit2",
								"originalName": "Cover_Outfit2",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4899638009709,
									"height": 117.1420702719133
								},
								"layerFrame": {
									"x": 221.00000000000003,
									"y": 464.00000000000006,
									"width": 126,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Cover_Outfit2-qzi1quy3.png",
									"frame": {
										"x": 221.00000000000003,
										"y": 464.00000000000006,
										"width": 126,
										"height": 123
									}
								},
								"children": []
							},
							{
								"objectId": "BE1A417F-EC2D-46BF-9E38-12CB274207BB",
								"kind": "group",
								"name": "Outfit_4",
								"originalName": "Outfit_4",
								"maskFrame": {
									"x": 0,
									"y": 0,
									"width": 119.4899638009714,
									"height": 117.1420702719133
								},
								"layerFrame": {
									"x": 62,
									"y": 464.00000000000006,
									"width": 125,
									"height": 123
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Outfit_4-qkuxqtqx.png",
									"frame": {
										"x": 62,
										"y": 464.00000000000006,
										"width": 125,
										"height": 123
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "6BF8632B-08E4-4834-B33E-3B8DB1C7076C",
						"kind": "group",
						"name": "Swipe",
						"originalName": "Swipe",
						"maskFrame": null,
						"layerFrame": {
							"x": 193,
							"y": 624,
							"width": 38,
							"height": 11
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Swipe-nkjgodyz.png",
							"frame": {
								"x": 193,
								"y": 624,
								"width": 38,
								"height": 11
							}
						},
						"children": []
					},
					{
						"objectId": "C1F2176D-25EB-4F4B-A31F-052E60AB8936",
						"kind": "group",
						"name": "Back1",
						"originalName": "Back",
						"maskFrame": null,
						"layerFrame": {
							"x": -5,
							"y": -5,
							"width": 425,
							"height": 746
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Back-qzfgmje3.png",
							"frame": {
								"x": -5,
								"y": -5,
								"width": 425,
								"height": 746
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "2D990BA4-C9A6-4B09-8B8B-F9AFC21C5FA2",
		"kind": "artboard",
		"name": "Style_Copy",
		"originalName": "Style Copy",
		"maskFrame": null,
		"layerFrame": {
			"x": 1142,
			"y": 67,
			"width": 414,
			"height": 736
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "855FE90C-F627-49FC-94A8-80B92187F6D9",
				"kind": "group",
				"name": "Top1",
				"originalName": "Top",
				"maskFrame": null,
				"layerFrame": {
					"x": 21,
					"y": 53,
					"width": 317,
					"height": 52
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Top-odu1rku5.png",
					"frame": {
						"x": 21,
						"y": 53,
						"width": 317,
						"height": 52
					}
				},
				"children": []
			},
			{
				"objectId": "1CE32FB0-DF0D-4514-9190-4F56833DB37E",
				"kind": "group",
				"name": "Cover",
				"originalName": "Cover",
				"maskFrame": null,
				"layerFrame": {
					"x": 227,
					"y": 151,
					"width": 123,
					"height": 119
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Cover-munfmzjg.png",
					"frame": {
						"x": 227,
						"y": 151,
						"width": 123,
						"height": 119
					}
				},
				"children": []
			},
			{
				"objectId": "3624E004-A70D-41B5-B1DA-DF908B0EDB30",
				"kind": "group",
				"name": "Cover21",
				"originalName": "Cover2",
				"maskFrame": null,
				"layerFrame": {
					"x": 227,
					"y": 465,
					"width": 123,
					"height": 119
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Cover2-mzyyneuw.png",
					"frame": {
						"x": 227,
						"y": 465,
						"width": 123,
						"height": 119
					}
				},
				"children": []
			},
			{
				"objectId": "F2F84490-D89F-417C-B748-BA9F985C904A",
				"kind": "group",
				"name": "Outfits_Copy",
				"originalName": "Outfits Copy",
				"maskFrame": null,
				"layerFrame": {
					"x": 62,
					"y": 148,
					"width": 290,
					"height": 439
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "B161F5E5-D0CC-4CE7-906F-4419087F69A1",
						"kind": "group",
						"name": "Outfit_5",
						"originalName": "Outfit_5",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7550202441205,
							"height": 118.044110880936
						},
						"layerFrame": {
							"x": 62,
							"y": 305,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_5-qje2muy1.png",
							"frame": {
								"x": 62,
								"y": 305,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					},
					{
						"objectId": "1DF511C3-6826-4515-BA83-09223B8031AA",
						"kind": "group",
						"name": "Outfit_31",
						"originalName": "Outfit_3",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7550202441205,
							"height": 118.0441108809363
						},
						"layerFrame": {
							"x": 62,
							"y": 148,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_3-murgntex.png",
							"frame": {
								"x": 62,
								"y": 148,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					},
					{
						"objectId": "4F9CE6AE-34E2-4C8A-A468-93C8B00029B2",
						"kind": "group",
						"name": "Cover_Outfit3",
						"originalName": "Cover_Outfit3",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7559333999669,
							"height": 118.0449962051698
						},
						"layerFrame": {
							"x": 224,
							"y": 148,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Cover_Outfit3-ney5q0u2.png",
							"frame": {
								"x": 224,
								"y": 148,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					},
					{
						"objectId": "001E8C79-0B67-4F7B-9875-F08375BC881B",
						"kind": "group",
						"name": "Outfit_21",
						"originalName": "Outfit_2",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7550202441206,
							"height": 118.044110880936
						},
						"layerFrame": {
							"x": 224,
							"y": 305,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_2-mdaxrthd.png",
							"frame": {
								"x": 224,
								"y": 305,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					},
					{
						"objectId": "A2FD4F05-F6D8-4C1D-8D8B-E693ABBE52DC",
						"kind": "group",
						"name": "Outfit_32",
						"originalName": "Outfit_3",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7550202441206,
							"height": 118.0441108809362
						},
						"layerFrame": {
							"x": 224,
							"y": 463,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_3-qtjgrdrg.png",
							"frame": {
								"x": 224,
								"y": 463,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					},
					{
						"objectId": "25BCE37C-9382-4E81-AC0D-9C7775C159F2",
						"kind": "group",
						"name": "Outfit_41",
						"originalName": "Outfit_4",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 121.7550202441205,
							"height": 118.0441108809362
						},
						"layerFrame": {
							"x": 62,
							"y": 463,
							"width": 128,
							"height": 124
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_4-mjvcq0uz.png",
							"frame": {
								"x": 62,
								"y": 463,
								"width": 128,
								"height": 124
							}
						},
						"children": []
					}
				]
			},
			{
				"objectId": "75618F64-32E2-4A66-8D9F-58E9C077B26F",
				"kind": "group",
				"name": "MenInput2",
				"originalName": "MenInput",
				"maskFrame": null,
				"layerFrame": {
					"x": 115,
					"y": 660,
					"width": 209,
					"height": 50
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-MenInput-nzu2mthg.png",
					"frame": {
						"x": 115,
						"y": 660,
						"width": 209,
						"height": 50
					}
				},
				"children": []
			},
			{
				"objectId": "0A62ABEA-5D99-4ADF-B548-C1A36CB0C7A7",
				"kind": "group",
				"name": "Onboarding_21",
				"originalName": "Onboarding_2",
				"maskFrame": null,
				"layerFrame": {
					"x": -5,
					"y": -5,
					"width": 425,
					"height": 746
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "C85E122A-A4E7-4B7F-9CA2-9CBA2173F2B3",
						"kind": "group",
						"name": "Swipe1",
						"originalName": "Swipe",
						"maskFrame": null,
						"layerFrame": {
							"x": 193.0000000000001,
							"y": 624,
							"width": 38,
							"height": 11
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Swipe-qzg1rtey.png",
							"frame": {
								"x": 193.0000000000001,
								"y": 624,
								"width": 38,
								"height": 11
							}
						},
						"children": []
					},
					{
						"objectId": "47285C5D-8AE3-4552-8BEE-2789054224AC",
						"kind": "group",
						"name": "Back2",
						"originalName": "Back",
						"maskFrame": null,
						"layerFrame": {
							"x": -5,
							"y": -5,
							"width": 425,
							"height": 746
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Back-ndcyodvd.png",
							"frame": {
								"x": -5,
								"y": -5,
								"width": 425,
								"height": 746
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "118A6343-C0FC-4B69-AD32-D7C47DDAA20E",
		"kind": "artboard",
		"name": "Artboard",
		"originalName": "Artboard",
		"maskFrame": null,
		"layerFrame": {
			"x": 668,
			"y": 972,
			"width": 888,
			"height": 425
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "A73EFCAF-211C-4319-8681-1947BC9FB687",
				"kind": "group",
				"name": "Outfits1",
				"originalName": "Outfits",
				"maskFrame": null,
				"layerFrame": {
					"x": 62,
					"y": -3,
					"width": 290,
					"height": 439
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "F262EE6D-FC8B-43FE-8271-5B784367D73A",
						"kind": "group",
						"name": "Outfit_11",
						"originalName": "Outfit_1",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4897881386352,
							"height": 117.1418980612181
						},
						"layerFrame": {
							"x": 227,
							"y": -3,
							"width": 125,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_1-rji2mkvf.png",
							"frame": {
								"x": 227,
								"y": -3,
								"width": 125,
								"height": 123
							}
						},
						"children": []
					},
					{
						"objectId": "BB4158D8-9BBD-4284-9199-C2B37F6CAFD3",
						"kind": "group",
						"name": "Cover_Outfit11",
						"originalName": "Cover_Outfit1",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4899638009714,
							"height": 117.1420702719137
						},
						"layerFrame": {
							"x": 62,
							"y": 0.999999999999956,
							"width": 125,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Cover_Outfit1-qki0mtu4.png",
							"frame": {
								"x": 62,
								"y": 0.999999999999956,
								"width": 125,
								"height": 123
							}
						},
						"children": []
					},
					{
						"objectId": "FB78859E-16DF-4656-8D0F-F5261CCA5042",
						"kind": "group",
						"name": "Outfit_22",
						"originalName": "Outfit_2",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4899638009714,
							"height": 117.1420702719137
						},
						"layerFrame": {
							"x": 62,
							"y": 156.9999999999999,
							"width": 125,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_2-rki3odg1.png",
							"frame": {
								"x": 62,
								"y": 156.9999999999999,
								"width": 125,
								"height": 123
							}
						},
						"children": []
					},
					{
						"objectId": "9ED3DAFC-99D1-4A57-AFB7-180A5117DCFD",
						"kind": "group",
						"name": "Outfit_33",
						"originalName": "Outfit_3",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4899638009717,
							"height": 117.1420702719137
						},
						"layerFrame": {
							"x": 227,
							"y": 156.9999999999999,
							"width": 125,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_3-ouvem0rb.png",
							"frame": {
								"x": 227,
								"y": 156.9999999999999,
								"width": 125,
								"height": 123
							}
						},
						"children": []
					},
					{
						"objectId": "15CA6017-0BB2-4CB7-8A61-E3BC31553B79",
						"kind": "group",
						"name": "Cover_Outfit21",
						"originalName": "Cover_Outfit2",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4899638009709,
							"height": 117.1420702719133
						},
						"layerFrame": {
							"x": 221.00000000000003,
							"y": 313.00000000000006,
							"width": 126,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Cover_Outfit2-mtvdqtyw.png",
							"frame": {
								"x": 221.00000000000003,
								"y": 313.00000000000006,
								"width": 126,
								"height": 123
							}
						},
						"children": []
					},
					{
						"objectId": "0DA4B9F6-18F1-4B11-A368-D2229327C49D",
						"kind": "group",
						"name": "Outfit_42",
						"originalName": "Outfit_4",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 119.4899638009714,
							"height": 117.1420702719133
						},
						"layerFrame": {
							"x": 62,
							"y": 313.00000000000006,
							"width": 125,
							"height": 123
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Outfit_4-merbnei5.png",
							"frame": {
								"x": 62,
								"y": 313.00000000000006,
								"width": 125,
								"height": 123
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "73624476-55FB-4943-A741-C21CDEBE84C6",
		"kind": "artboard",
		"name": "iPhone_7_Plus",
		"originalName": "iPhone 7 Plus",
		"maskFrame": null,
		"layerFrame": {
			"x": 1656,
			"y": 67,
			"width": 414,
			"height": 736
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"image": {
			"path": "images/Layer-iPhone_7_Plus-nzm2mjq0.jpg",
			"frame": {
				"x": 1656,
				"y": 67,
				"width": 414,
				"height": 736
			}
		},
		"children": []
	}
]