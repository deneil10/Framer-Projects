window.__imported__ = window.__imported__ || {};
window.__imported__["framr@1x/layers.json.js"] = [
	{
		"objectId": "F6FA7E95-E3CD-428B-BEC4-B77AEFF048A8",
		"kind": "artboard",
		"name": "Home_iPhone7_",
		"originalName": "Home(iPhone7)",
		"maskFrame": null,
		"layerFrame": {
			"x": 1474,
			"y": 1783,
			"width": 1242,
			"height": 2208
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "C37B27BF-5A4A-40AA-92C0-AB2439143D0E",
				"kind": "group",
				"name": "Home",
				"originalName": "Home",
				"maskFrame": null,
				"layerFrame": {
					"x": 39,
					"y": 149,
					"width": 1193,
					"height": 751
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Home-qzm3qji3.png",
					"frame": {
						"x": 39,
						"y": 149,
						"width": 1193,
						"height": 751
					}
				},
				"children": [
					{
						"objectId": "C8ED153B-0BB6-4802-BCD6-444D76EE9416",
						"kind": "group",
						"name": "Options",
						"originalName": "Options",
						"maskFrame": null,
						"layerFrame": {
							"x": 39,
							"y": 463,
							"width": 1193,
							"height": 437
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "213C296B-587B-4E49-9600-F9A0DA030C18",
								"kind": "group",
								"name": "Basic",
								"originalName": "Basic",
								"maskFrame": null,
								"layerFrame": {
									"x": 39,
									"y": 463,
									"width": 338,
									"height": 433
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Basic-mjezqzi5.png",
									"frame": {
										"x": 39,
										"y": 463,
										"width": 338,
										"height": 433
									}
								},
								"children": [
									{
										"objectId": "0FB6341A-3C48-4E63-B144-7619C56D2554",
										"kind": "group",
										"name": "Button",
										"originalName": "Button",
										"maskFrame": null,
										"layerFrame": {
											"x": 96.00000000000003,
											"y": 520,
											"width": 224,
											"height": 224
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "A45FB373-265C-4D44-96F8-A489F33627DD",
												"kind": "group",
												"name": "Button1",
												"originalName": "Button",
												"maskFrame": null,
												"layerFrame": {
													"x": 95.99585557031241,
													"y": 519.8668303938975,
													"width": 224,
													"height": 224
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Button-qtq1rkiz.png",
													"frame": {
														"x": 95.99585557031241,
														"y": 519.8668303938975,
														"width": 224,
														"height": 224
													}
												},
												"children": []
											}
										]
									},
									{
										"objectId": "8DFCCE2C-65BE-49CA-B8C8-C2FB10B132A0",
										"kind": "group",
										"name": "Basic1",
										"originalName": "Basic",
										"maskFrame": null,
										"layerFrame": {
											"x": 96.9999999999999,
											"y": 758.9999999999998,
											"width": 222,
											"height": 87
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Basic-oergq0nf.png",
											"frame": {
												"x": 96.9999999999999,
												"y": 758.9999999999998,
												"width": 222,
												"height": 87
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "91FF78DC-4481-428F-A31F-A123A0E38577",
								"kind": "group",
								"name": "Friends",
								"originalName": "Friends",
								"maskFrame": null,
								"layerFrame": {
									"x": 465,
									"y": 463,
									"width": 338,
									"height": 436
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Friends-otfgrjc4.png",
									"frame": {
										"x": 465,
										"y": 463,
										"width": 338,
										"height": 436
									}
								},
								"children": [
									{
										"objectId": "673B1C61-E3E2-4F80-9BD4-6C9917988F74",
										"kind": "group",
										"name": "buttons",
										"originalName": "buttons",
										"maskFrame": null,
										"layerFrame": {
											"x": 535.0000000000001,
											"y": 538.0000000000001,
											"width": 206,
											"height": 190
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "A654B47B-E57B-4B0A-95CD-78BA0FD8AC04",
												"kind": "group",
												"name": "Body",
												"originalName": "Body",
												"maskFrame": null,
												"layerFrame": {
													"x": 535.3405352893931,
													"y": 538.2902310312431,
													"width": 137,
													"height": 137
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "C5C4C85B-41F8-4F25-9353-D6988B0093D5",
														"kind": "group",
														"name": "Button2",
														"originalName": "Button",
														"maskFrame": null,
														"layerFrame": {
															"x": 535.4044320202042,
															"y": 537.7556047997591,
															"width": 136,
															"height": 137
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Button-qzvdnem4.png",
															"frame": {
																"x": 535.4044320202042,
																"y": 537.7556047997591,
																"width": 136,
																"height": 137
															}
														},
														"children": []
													}
												]
											},
											{
												"objectId": "C26F6228-0CB6-4BD3-B5BC-80DD9501830A",
												"kind": "group",
												"name": "Body1",
												"originalName": "Body",
												"maskFrame": null,
												"layerFrame": {
													"x": 603.3405352893931,
													"y": 591.2902310312434,
													"width": 138,
													"height": 136
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "D6905300-4FD0-456E-A9F7-0735671EF2C7",
														"kind": "group",
														"name": "Button3",
														"originalName": "Button",
														"maskFrame": null,
														"layerFrame": {
															"x": 604.2275638647347,
															"y": 590.3008557774338,
															"width": 136,
															"height": 137
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Button-rdy5mduz.png",
															"frame": {
																"x": 604.2275638647347,
																"y": 590.3008557774338,
																"width": 136,
																"height": 137
															}
														},
														"children": []
													}
												]
											}
										]
									},
									{
										"objectId": "644BC5C8-F022-44C5-8F4C-5D0D69D583DD",
										"kind": "group",
										"name": "Friends1",
										"originalName": "Friends",
										"maskFrame": null,
										"layerFrame": {
											"x": 522.9999999999999,
											"y": 759.9999999999998,
											"width": 222,
											"height": 87
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Friends-njq0qkm1.png",
											"frame": {
												"x": 522.9999999999999,
												"y": 759.9999999999998,
												"width": 222,
												"height": 87
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "CA25B33D-B5E7-44D7-866D-B9C71678E396",
								"kind": "group",
								"name": "Premium",
								"originalName": "Premium",
								"maskFrame": null,
								"layerFrame": {
									"x": 894,
									"y": 464,
									"width": 338,
									"height": 436
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Premium-q0eynuiz.png",
									"frame": {
										"x": 894,
										"y": 464,
										"width": 338,
										"height": 436
									}
								},
								"children": [
									{
										"objectId": "88F935A5-0663-4C60-ADA5-B1F235755A10",
										"kind": "group",
										"name": "Premium1",
										"originalName": "Premium",
										"maskFrame": null,
										"layerFrame": {
											"x": 952.0000000000001,
											"y": 758.9999999999998,
											"width": 222,
											"height": 87
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Premium-odhgotm1.png",
											"frame": {
												"x": 952.0000000000001,
												"y": 758.9999999999998,
												"width": 222,
												"height": 87
											}
										},
										"children": []
									},
									{
										"objectId": "F6AD9D72-3F65-442E-B2B7-6A2A915B8251",
										"kind": "group",
										"name": "Premium_button",
										"originalName": "Premium_button",
										"maskFrame": null,
										"layerFrame": {
											"x": 951,
											"y": 520,
											"width": 224,
											"height": 224
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "563A5E01-76DF-4E1C-B689-E74BFC649A32",
												"kind": "group",
												"name": "Button4",
												"originalName": "Button",
												"maskFrame": null,
												"layerFrame": {
													"x": 951.16019157253,
													"y": 520.0559172898566,
													"width": 223,
													"height": 224
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Button-ntyzqtvf.png",
													"frame": {
														"x": 951.16019157253,
														"y": 520.0559172898566,
														"width": 223,
														"height": 224
													}
												},
												"children": []
											}
										]
									}
								]
							}
						]
					},
					{
						"objectId": "0E30322F-7720-40FE-A352-9F4B8F4B3CBC",
						"kind": "group",
						"name": "Hamburger_Icon",
						"originalName": "Hamburger_Icon",
						"maskFrame": null,
						"layerFrame": {
							"x": 66,
							"y": 149,
							"width": 103,
							"height": 82
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Hamburger_Icon-meuzmdmy.png",
							"frame": {
								"x": 66,
								"y": 149,
								"width": 103,
								"height": 82
							}
						},
						"children": []
					}
				]
			},
			{
				"objectId": "31225EAA-E6EC-44B7-8F28-5326AB36DA7C",
				"kind": "group",
				"name": "Back",
				"originalName": "Back",
				"maskFrame": null,
				"layerFrame": {
					"x": -13,
					"y": -13,
					"width": 1268,
					"height": 2234
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Back-mzeymjvf.png",
					"frame": {
						"x": -13,
						"y": -13,
						"width": 1268,
						"height": 2234
					}
				},
				"children": []
			}
		]
	},
	{
		"objectId": "2ABB47A6-7B82-4CDC-893C-DBA09FF76042",
		"kind": "artboard",
		"name": "Success_iPhone7_",
		"originalName": "Success(iPhone7)",
		"maskFrame": null,
		"layerFrame": {
			"x": 2957,
			"y": 1783,
			"width": 1242,
			"height": 2208
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "0A8CDAD1-401C-46F2-BBFC-B939FC6840E1",
				"kind": "group",
				"name": "Success",
				"originalName": "Success",
				"maskFrame": null,
				"layerFrame": {
					"x": -13,
					"y": -13,
					"width": 1268,
					"height": 2234
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Success-mee4q0rb.png",
					"frame": {
						"x": -13,
						"y": -13,
						"width": 1268,
						"height": 2234
					}
				},
				"children": [
					{
						"objectId": "1E94B996-8607-4EDC-B99A-E126636CD612",
						"kind": "group",
						"name": "OPTIONS",
						"originalName": "OPTIONS",
						"maskFrame": null,
						"layerFrame": {
							"x": 161,
							"y": 1887,
							"width": 922,
							"height": 245
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-OPTIONS-muu5nei5.png",
							"frame": {
								"x": 161,
								"y": 1887,
								"width": 922,
								"height": 245
							}
						},
						"children": [
							{
								"objectId": "9861B35F-968C-44B1-B18A-AABE7241A8EC",
								"kind": "group",
								"name": "Contact",
								"originalName": "Contact",
								"maskFrame": null,
								"layerFrame": {
									"x": 670.9999999999999,
									"y": 1930.9999999999998,
									"width": 203,
									"height": 171
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Contact-otg2muiz.png",
									"frame": {
										"x": 670.9999999999999,
										"y": 1930.9999999999998,
										"width": 203,
										"height": 171
									}
								},
								"children": []
							},
							{
								"objectId": "F05FCD7F-29BA-4E73-9B37-BC31434AF3BB",
								"kind": "group",
								"name": "Cancel",
								"originalName": "Cancel",
								"maskFrame": null,
								"layerFrame": {
									"x": 375,
									"y": 1929.9999999999998,
									"width": 177,
									"height": 168
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Cancel-rja1rkne.png",
									"frame": {
										"x": 375,
										"y": 1929.9999999999998,
										"width": 177,
										"height": 168
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "1F567629-5970-484F-80BE-FE4C21E7745C",
						"kind": "group",
						"name": "Card",
						"originalName": "Card",
						"maskFrame": null,
						"layerFrame": {
							"x": 156,
							"y": 381,
							"width": 929,
							"height": 1420
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "86635123-FBB8-4A5F-A4A1-872A304C668C",
								"kind": "group",
								"name": "Top",
								"originalName": "Top",
								"maskFrame": null,
								"layerFrame": {
									"x": 417.99999999999983,
									"y": 381,
									"width": 404,
									"height": 546
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "96F6B2E9-2C09-4698-9155-D3043E24B570",
										"kind": "group",
										"name": "P_Stylist_1",
										"originalName": "P_Stylist_1",
										"maskFrame": {
											"x": 6.548311990686846,
											"y": 0,
											"width": 392.8987194412107,
											"height": 392.8987194412107
										},
										"layerFrame": {
											"x": 418.00349243306164,
											"y": 381,
											"width": 404,
											"height": 546
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-P_Stylist_1-otzgnkiy.png",
											"frame": {
												"x": 418.00349243306164,
												"y": 381,
												"width": 404,
												"height": 546
											}
										},
										"children": [
											{
												"objectId": "819DD124-8A04-4042-998B-CC78901ED8B0",
												"kind": "group",
												"name": "Stars",
												"originalName": "Stars",
												"maskFrame": null,
												"layerFrame": {
													"x": 477.0034924330619,
													"y": 891.0000000000002,
													"width": 213,
													"height": 36
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Stars-ode5reqx.png",
													"frame": {
														"x": 477.0034924330619,
														"y": 891.0000000000002,
														"width": 213,
														"height": 36
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "E1A8EEFF-3365-499E-A06D-5FC6185F5641",
								"kind": "group",
								"name": "Meet",
								"originalName": "Meet",
								"maskFrame": null,
								"layerFrame": {
									"x": 156,
									"y": 1403.0000000000002,
									"width": 928,
									"height": 398
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Meet-rtfboevf.png",
									"frame": {
										"x": 156,
										"y": 1403.0000000000002,
										"width": 928,
										"height": 398
									}
								},
								"children": [
									{
										"objectId": "6945FDB2-14E0-49EA-A90A-177CAE4A7A94",
										"kind": "group",
										"name": "Route_me",
										"originalName": "Route me",
										"maskFrame": null,
										"layerFrame": {
											"x": 306.0000000000001,
											"y": 1657.9173457508728,
											"width": 628,
											"height": 143
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Route_me-njk0nuze.png",
											"frame": {
												"x": 306.0000000000001,
												"y": 1657.9173457508728,
												"width": 628,
												"height": 143
											}
										},
										"children": []
									},
									{
										"objectId": "243B71AF-6984-4922-8FBF-4F4BF0769E3A",
										"kind": "group",
										"name": "Address",
										"originalName": "Address",
										"maskFrame": null,
										"layerFrame": {
											"x": 308,
											"y": 1528.917345750873,
											"width": 625,
											"height": 84
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Address-mjqzqjcx.png",
											"frame": {
												"x": 308,
												"y": 1528.917345750873,
												"width": 625,
												"height": 84
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "C273E647-E1AA-4EC0-9384-F6B9AB326FE0",
								"kind": "group",
								"name": "Time",
								"originalName": "Time",
								"maskFrame": null,
								"layerFrame": {
									"x": 156.99999999999997,
									"y": 982,
									"width": 928,
									"height": 344
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Time-qzi3m0u2.png",
									"frame": {
										"x": 156.99999999999997,
										"y": 982,
										"width": 928,
										"height": 344
									}
								},
								"children": [
									{
										"objectId": "838EEA03-9701-44FD-B31E-3CE3D84DED7B",
										"kind": "group",
										"name": "Add",
										"originalName": "Add",
										"maskFrame": null,
										"layerFrame": {
											"x": 307.30966239813745,
											"y": 1182.2060535506403,
											"width": 628,
											"height": 144
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Add-odm4ruvb.png",
											"frame": {
												"x": 307.30966239813745,
												"y": 1182.2060535506403,
												"width": 628,
												"height": 144
											}
										},
										"children": []
									}
								]
							}
						]
					},
					{
						"objectId": "B0E1CFD5-3ABA-448B-A447-0E4382C9A500",
						"kind": "group",
						"name": "Back1",
						"originalName": "Back",
						"maskFrame": null,
						"layerFrame": {
							"x": -13,
							"y": -13,
							"width": 1268,
							"height": 2234
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Back-qjbfmung.png",
							"frame": {
								"x": -13,
								"y": -13,
								"width": 1268,
								"height": 2234
							}
						},
						"children": []
					}
				]
			}
		]
	}
]