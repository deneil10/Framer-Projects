window.__imported__ = window.__imported__ || {};
window.__imported__["Onboarding_Animateion@1x/layers.json.js"] = [
	{
		"objectId": "9FB77546-C4AA-45BC-908B-0245F2F4F468",
		"kind": "artboard",
		"name": "Home_iPhone7_",
		"originalName": "Home(iPhone7)",
		"maskFrame": null,
		"layerFrame": {
			"x": 36663,
			"y": -15492,
			"width": 1242,
			"height": 2208
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "FAC53000-6FB5-44BC-8B95-1E88F236418E",
				"kind": "group",
				"name": "Home",
				"originalName": "Home",
				"maskFrame": null,
				"layerFrame": {
					"x": 66,
					"y": 149,
					"width": 1093,
					"height": 734
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Home-rkfdntmw.png",
					"frame": {
						"x": 66,
						"y": 149,
						"width": 1093,
						"height": 734
					}
				},
				"children": [
					{
						"objectId": "EE19766C-0A06-416C-946C-FFEE11FF7883",
						"kind": "group",
						"name": "Options",
						"originalName": "Options",
						"maskFrame": null,
						"layerFrame": {
							"x": 83,
							"y": 487,
							"width": 1076,
							"height": 396
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "FAB1A963-19A4-40D9-A07C-75818BA72982",
								"kind": "group",
								"name": "Basic",
								"originalName": "Basic",
								"maskFrame": null,
								"layerFrame": {
									"x": 83,
									"y": 487,
									"width": 305,
									"height": 392
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Basic-rkfcmue5.png",
									"frame": {
										"x": 83,
										"y": 487,
										"width": 305,
										"height": 392
									}
								},
								"children": [
									{
										"objectId": "9806D183-A063-4BCB-A7B4-0B46ACFCAD85",
										"kind": "group",
										"name": "Button",
										"originalName": "Button",
										"maskFrame": null,
										"layerFrame": {
											"x": 133.99999999999878,
											"y": 538.9999999999997,
											"width": 202,
											"height": 202
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "C249DF4C-77D3-4298-9837-B23CFEAB50A3",
												"kind": "group",
												"name": "Button1",
												"originalName": "Button",
												"maskFrame": null,
												"layerFrame": {
													"x": 134.86808754553203,
													"y": 539.2030760346988,
													"width": 201,
													"height": 202
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Button-qzi0ourg.png",
													"frame": {
														"x": 134.86808754553203,
														"y": 539.2030760346988,
														"width": 201,
														"height": 202
													}
												},
												"children": []
											}
										]
									},
									{
										"objectId": "C49AC639-3DE2-4F6C-BD9F-7D4A87353FDE",
										"kind": "group",
										"name": "Basic1",
										"originalName": "Basic",
										"maskFrame": null,
										"layerFrame": {
											"x": 135.00000000000364,
											"y": 754.9999999999999,
											"width": 201,
											"height": 80
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Basic-qzq5qum2.png",
											"frame": {
												"x": 135.00000000000364,
												"y": 754.9999999999999,
												"width": 201,
												"height": 80
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "1F62B9D1-D1B9-49D5-9FC8-B587615D8F8E",
								"kind": "group",
								"name": "Friends",
								"originalName": "Friends",
								"maskFrame": null,
								"layerFrame": {
									"x": 466.00000000000006,
									"y": 487,
									"width": 306,
									"height": 394
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Friends-muy2mki5.png",
									"frame": {
										"x": 466.00000000000006,
										"y": 487,
										"width": 306,
										"height": 394
									}
								},
								"children": [
									{
										"objectId": "6B1F5E1B-0B62-4C39-B354-C78177BCDB2B",
										"kind": "group",
										"name": "buttons",
										"originalName": "buttons",
										"maskFrame": null,
										"layerFrame": {
											"x": 529.8383921139392,
											"y": 555.0000000000003,
											"width": 186,
											"height": 171
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "1C63F55F-754F-4681-B48F-A514A647BAE8",
												"kind": "group",
												"name": "Body",
												"originalName": "Body",
												"maskFrame": null,
												"layerFrame": {
													"x": 530.6050320845806,
													"y": 555.3716496105317,
													"width": 123,
													"height": 123
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "3A16DBB9-DA7E-4A69-8BF2-00F060DD59CF",
														"kind": "group",
														"name": "Button2",
														"originalName": "Button",
														"maskFrame": null,
														"layerFrame": {
															"x": 530.6105771290095,
															"y": 555.1684744846989,
															"width": 123,
															"height": 123
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Button-m0exnkrc.png",
															"frame": {
																"x": 530.6105771290095,
																"y": 555.1684744846989,
																"width": 123,
																"height": 123
															}
														},
														"children": []
													}
												]
											},
											{
												"objectId": "F7B71439-EB43-4489-9F94-C783E81ECDA5",
												"kind": "group",
												"name": "Body1",
												"originalName": "Body",
												"maskFrame": null,
												"layerFrame": {
													"x": 591.6050320845827,
													"y": 602.3716496105305,
													"width": 124,
													"height": 123
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "B72ECA8D-2D71-47EF-A477-D58089F0272A",
														"kind": "group",
														"name": "Button3",
														"originalName": "Button",
														"maskFrame": null,
														"layerFrame": {
															"x": 592.5094304647937,
															"y": 602.4671186644118,
															"width": 123,
															"height": 123
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Button-qjcyrunb.png",
															"frame": {
																"x": 592.5094304647937,
																"y": 602.4671186644118,
																"width": 123,
																"height": 123
															}
														},
														"children": []
													}
												]
											}
										]
									},
									{
										"objectId": "1C6EBF96-3AE4-42F7-AC7B-0C384CAF05C3",
										"kind": "group",
										"name": "Friends1",
										"originalName": "Friends",
										"maskFrame": null,
										"layerFrame": {
											"x": 518.8383921139366,
											"y": 754.9999999999999,
											"width": 201,
											"height": 80
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Friends-mum2rujg.png",
											"frame": {
												"x": 518.8383921139366,
												"y": 754.9999999999999,
												"width": 201,
												"height": 80
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "72EE9882-0784-49A3-88BD-CAAD0185A713",
								"kind": "group",
								"name": "Premium",
								"originalName": "Premium",
								"maskFrame": null,
								"layerFrame": {
									"x": 853,
									"y": 488.00000000000045,
									"width": 306,
									"height": 395
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Premium-nzjfrtk4.png",
									"frame": {
										"x": 853,
										"y": 488.00000000000045,
										"width": 306,
										"height": 395
									}
								},
								"children": [
									{
										"objectId": "670DD61D-B0BB-4F6E-A68A-0CBABB1BE0E8",
										"kind": "group",
										"name": "Premium1",
										"originalName": "Premium",
										"maskFrame": null,
										"layerFrame": {
											"x": 905.2968415119293,
											"y": 754.3095155977855,
											"width": 201,
											"height": 80
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Premium-njcwreq2.png",
											"frame": {
												"x": 905.2968415119293,
												"y": 754.3095155977855,
												"width": 201,
												"height": 80
											}
										},
										"children": []
									},
									{
										"objectId": "B18443BA-7552-48A6-9024-8CED7DFC2F83",
										"kind": "group",
										"name": "Premium_button",
										"originalName": "Premium_button",
										"maskFrame": null,
										"layerFrame": {
											"x": 904.2968415119296,
											"y": 539.3095155977855,
											"width": 202,
											"height": 201
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "B796B005-7151-4331-9A3E-185F65BF7132",
												"kind": "group",
												"name": "Button4",
												"originalName": "Button",
												"maskFrame": null,
												"layerFrame": {
													"x": 905.123909725633,
													"y": 539.0946591879656,
													"width": 201,
													"height": 202
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Button-qjc5nkiw.png",
													"frame": {
														"x": 905.123909725633,
														"y": 539.0946591879656,
														"width": 201,
														"height": 202
													}
												},
												"children": []
											}
										]
									}
								]
							}
						]
					},
					{
						"objectId": "3032E4D1-9A60-4506-9EF0-ABC45B1BBD5C",
						"kind": "group",
						"name": "Hamburger_Icon",
						"originalName": "Hamburger_Icon",
						"maskFrame": null,
						"layerFrame": {
							"x": 66.00000000000364,
							"y": 149.0000000000009,
							"width": 103,
							"height": 82
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Hamburger_Icon-mzazmku0.png",
							"frame": {
								"x": 66.00000000000364,
								"y": 149.0000000000009,
								"width": 103,
								"height": 82
							}
						},
						"children": []
					}
				]
			},
			{
				"objectId": "833EF321-284F-4B5C-8F37-A79E0894C21A",
				"kind": "group",
				"name": "Back",
				"originalName": "Back",
				"maskFrame": null,
				"layerFrame": {
					"x": -13,
					"y": -13,
					"width": 1268,
					"height": 2234
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-Back-odmzruyz.png",
					"frame": {
						"x": -13,
						"y": -13,
						"width": 1268,
						"height": 2234
					}
				},
				"children": []
			}
		]
	}
]